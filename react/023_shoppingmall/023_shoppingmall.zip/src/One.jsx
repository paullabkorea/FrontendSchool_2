import React from 'react'

export default function One() {
    return (
        <div>One</div>
    )
}
