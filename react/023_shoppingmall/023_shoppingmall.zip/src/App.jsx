import HomePage from './pages/HomePage/HomePage'
import './reset.css'
import './app.css'

function App() {
    // console.log(data)
    return (
        <>
            <HomePage/>
        </>
    );
}

export default App;